# Start Page

Newsly - a simple start-page for Chrome.

## Ideas

* Display quote
* Display word of the day
* Newsfeed